# Seaport Cam 1 / 2 / 3 — AMB82-MINI firmware

Three separate Arduino sketches for RTL8735BDM / AMB82-MINI. Each has a unique setup AP name and default static router address.

| Sketch | Setup AP SSID | Default router IP | Gateway example |
|---|---|---|---|
| `Camera1/Camera1.ino` | `Seaport_Cam_1` | `192.168.1.1` | `192.168.1.254` |
| `Camera2/Camera2.ino` | `Seaport_Cam_2` | `192.168.1.2` | `192.168.1.254` |
| `Camera3/Camera3.ino` | `Seaport_Cam_3` | `192.168.1.3` | `192.168.1.254` |

All setup APs use `192.168.10.1` on their own separate wireless networks. Default setup password is `12345678`.

## First-time workflow
1. Upload the matching `.ino` to the matching camera.
2. Connect to that camera's setup SSID and browse to `http://192.168.10.1/`.
3. Select the router SSID and enter its password; click **Save & Connect**.
4. Select **Static IP** and enter the camera IP, gateway, netmask, and DNS. Click **Save device settings**.
5. Click **Restart camera**. On reboot, the saved router profile will be tried with the saved static-IP settings.
6. Reopen the setup page and confirm the camera IP in status and Serial Monitor.

Use your actual LAN settings if they differ from the examples. Reserve `.1`, `.2`, and `.3` outside the router DHCP pool and make sure those addresses are not already in use. The original hard-coded router SSID/password are disabled; the router network is selected through the page.

See each camera folder's `README.txt` for detailed upload and troubleshooting steps.

**Validation note:** These sketches were generated from the supplied firmware and are not compiled or hardware-tested here. Verify AP startup and static IP on one camera before deploying the remaining two. RTSP code was not intentionally modified.
