SEAPORT CAM 3 — AMB82-MINI / RTL8735BDM
========================================

Firmware file: Camera3.ino
Setup AP SSID: Seaport_Cam_3
Setup AP password: 12345678 (change before deployment)
Setup page: http://192.168.10.1/
Default static router IP: 192.168.1.3
Default gateway and DNS: 192.168.1.254
Default subnet mask: 255.255.255.0
Hostname: Seaport-Cam-3

IMPORTANT
---------
- This sketch retains the original camera/RTSP implementation; RTSP settings and
  streaming code have not been intentionally changed.
- The old hard-coded router SSID/password are disabled. Select the actual router
  network from the setup page instead.
- Each camera has its own AP SSID. The setup AP address is the same on each
  separate AP: 192.168.10.1.
- Static router IPs must be unused and excluded from the router's DHCP pool.
- Confirm that 192.168.1.254 is your actual router gateway. Change the gateway,
  DNS, mask, and camera IP on the page if your LAN uses different values.
- The first time after flashing, connect to Seaport_Cam_3 and open the page.
  If the AP password was previously changed in saved settings, use that password.

UPLOAD
------
1. Open this Camera3.ino in Arduino IDE.
2. Select the board/core used by your working AMB82-MINI setup (AmebaPro2 SDK
   matching the project's existing AmebaPro2 Arduino SDK 4.1.0 environment).
3. Select the correct port and upload.
4. Open Serial Monitor at 115200 baud. Confirm that the AP starts and that the
   HTTP server reports http://192.168.10.1/.

CONFIGURATION PAGE — FIRST-TIME SETUP
------------------------------------
1. On your phone or laptop, connect to Wi-Fi SSID Seaport_Cam_3.
2. Enter the AP password: 12345678 (unless it was changed previously).
3. If the device says “No internet”, stay connected; this AP is only for setup.
4. Open a browser and enter http://192.168.10.1/ exactly. Disable mobile data/VPN
   temporarily if the browser tries to leave the camera's setup network.
5. Under “Wi-Fi networks”, click “Scan now” if the router list is empty. Refresh
   the page after scanning finishes. Select your router SSID from the list; enter
   its Wi-Fi password and click “Save & Connect”. Hidden SSIDs can be typed in.
6. Under “Camera IP on the router network (STA)”, select “Static IP”. Enter:
       Camera 3 IP: 192.168.1.3
       Gateway:      192.168.1.254
       Netmask:      255.255.255.0
       DNS:          192.168.1.254
   These are examples for a router using 192.168.1.0/24 and gateway .254. Use your
   real LAN values if they differ. Every camera must have a unique IP.
7. Click “Save device settings”. The page should report that settings are saved
   and pending restart.
8. Click “Restart camera”. Wait for reboot, then reconnect to Seaport_Cam_3
   and reopen http://192.168.10.1/ if needed. On boot, the saved router profile
   is retried with the saved static IP configuration.
9. Refresh the page and check Status and Camera IP. The Camera IP should be
   192.168.1.3. If the AP and router connection are both active, the setup page
   should remain reachable while the camera is connected to the router.
10. Check Serial Monitor for “[STA] VERIFIED static IP active: 192.168.1.3”.
    If it reports that the IP was not applied, do not assume the static IP worked.

ACCESS AFTER CONFIGURATION
--------------------------
- Setup page: connect to this camera's Seaport_Cam_3 AP, then browse to
  http://192.168.10.1/.
- Router-side camera address: http://192.168.1.3/ (if HTTP port remains 80).
- RTSP remains separate from the configuration workflow.

TROUBLESHOOTING
---------------
- AP not visible: reset/reboot the board, check Serial Monitor, and confirm the
  correct firmware was uploaded to that camera.
- Page does not load: make sure you are connected to Seaport_Cam_3, use
  http:// rather than https://, and enter 192.168.10.1 directly.
- Router connection fails: verify SSID/password and whether the router supports
  the camera's Wi-Fi band/security. Check Serial Monitor for connection status.
- Static IP not verified: confirm IP/gateway/netmask/DNS are in the same subnet,
  gateway is correct, and the IP is not already used or inside the DHCP pool.
- Cannot see new AP name after updating firmware: saved settings may have been
  retained by a prior firmware version. This firmware uses a new settings schema
  so its defaults should load; if the old AP remains, inspect Serial Monitor.

BUILD STATUS
------------
Prepared as a separate upload sketch for each camera, but not compiled against
hardware or verified on a physical AMB82-MINI in this environment. Test one camera
first and verify AP IP and static-IP logs before deploying all three.
